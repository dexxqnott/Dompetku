package com.dompetku.app;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content, nav;
    String tab="Home", filter="Semua";
    JSONArray transactions;
    JSONObject budgets;
    JSONArray goals;
    android.content.SharedPreferences prefs;
    final String[] expenseCats={"Makanan","Transportasi","Belanja","Tagihan","Hiburan","Kesehatan","Pendidikan","Investasi","Sedekah","Lainnya"};
    final String[] incomeCats={"Gaji","Bonus","Bisnis","Investasi","Hadiah","Lainnya"};
    final String[] tabs={"Home","Transaksi","Anggaran","Target","Lainnya"};
    final String[] icons={"⌂","↕","▤","◎","⚙"};

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("dompetku",MODE_PRIVATE);
        try{transactions=new JSONArray(prefs.getString("tx","[]"));budgets=new JSONObject(prefs.getString("budgets","{}"));goals=new JSONArray(prefs.getString("goals","[]"));}
        catch(Exception e){transactions=new JSONArray();budgets=new JSONObject();goals=new JSONArray();}
        build(); render();
    }
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    TextView text(String s,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);
        if(bold)t.setTypeface(null,Typeface.BOLD);return t;
    }
    int ink=Color.rgb(30,31,48), muted=Color.rgb(130,132,148), purple=Color.rgb(99,91,255);
    void build(){
        root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(Color.rgb(247,247,251));
        setContentView(root);
        LinearLayout header=new LinearLayout(this);header.setPadding(dp(18),dp(14),dp(18),dp(12));header.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand=text("💰 DompetKu",22,ink,true);header.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        Button add=button("+ Transaksi");add.setOnClickListener(v->transactionDialog());header.addView(add);root.addView(header);
        nav=new LinearLayout(this);nav.setPadding(dp(5),dp(5),dp(5),dp(5));nav.setBackgroundColor(Color.WHITE);
        for(int i=0;i<tabs.length;i++){final String x=tabs[i];TextView n=text(icons[i]+"\n"+x,10,muted,true);n.setGravity(Gravity.CENTER);n.setPadding(dp(2),dp(8),dp(2),dp(8));nav.addView(n,new LinearLayout.LayoutParams(0,-2,1));n.setOnClickListener(v->{tab=x;render();});}
        root.addView(nav);
        ScrollView scroll=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(1);content.setPadding(dp(15),dp(14),dp(15),dp(24));scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    }
    Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(13);b.setAllCaps(false);b.setBackground(bg(purple,12));return b;}
    void card(View v){LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(14),dp(14),dp(14),dp(14));box.setBackground(bg(Color.WHITE,16));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(10);box.addView(v);content.addView(box,p);}
    void label(String s){content.addView(text(s,16,ink,true));}
    String rupiah(double x){return "Rp"+NumberFormat.getNumberInstance(new Locale("in","ID")).format(x);}
    double sum(String type,String month){
        double s=0;for(int i=0;i<transactions.length();i++){JSONObject o=transactions.optJSONObject(i);if(o==null)continue;
        if(o.optString("type").equals(type)&&o.optString("date").startsWith(month))s+=o.optDouble("amount");}return s;
    }
    double balance(){double s=0;for(int i=0;i<transactions.length();i++){JSONObject o=transactions.optJSONObject(i);if(o==null)continue;s+=o.optString("type").equals("Pemasukan")?o.optDouble("amount"):-o.optDouble("amount");}return s;}
    String month(){return new SimpleDateFormat("yyyy-MM",Locale.US).format(new Date());}
    void save(){prefs.edit().putString("tx",transactions.toString()).putString("budgets",budgets.toString()).putString("goals",goals.toString()).apply();render();}
    void render(){
        content.removeAllViews();
        for(int i=0;i<tabs.length;i++){TextView n=(TextView)nav.getChildAt(i);n.setTextColor(tabs[i].equals(tab)?purple:muted);}
        double inc=sum("Pemasukan",month()),exp=sum("Pengeluaran",month());
        if(tab.equals("Home")){
            LinearLayout stats=new LinearLayout(this);stats.setOrientation(1);
            stats.addView(text("TOTAL SALDO",12,muted,true));stats.addView(text(rupiah(balance()),27,ink,true));
            stats.addView(text("Pemasukan bulan ini   "+rupiah(inc),14,Color.rgb(30,150,100),true));
            stats.addView(text("Pengeluaran bulan ini   "+rupiah(exp),14,Color.rgb(220,75,85),true));
            card(stats);label("Ringkasan bulan ini");card(text("💵  Pemasukan     "+rupiah(inc)+"\n\n🛒  Pengeluaran   "+rupiah(exp)+"\n\n📈  Selisih            "+rupiah(inc-exp),15,ink,false));
            label("Transaksi terbaru");showTransactions(5);
        }else if(tab.equals("Transaksi")){
            Button b=button("＋ Tambah transaksi");b.setOnClickListener(v->transactionDialog());card(b);
            showTransactions(200);
        }else if(tab.equals("Anggaran")){
            Button b=button("＋ Buat anggaran");b.setOnClickListener(v->budgetDialog());card(b);
            Iterator<String> it=budgets.keys();while(it.hasNext()){String cat=it.next();double lim=budgets.optDouble(cat),sp=sumCat(cat);
                LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.addView(text(cat,15,ink,true));l.addView(text(rupiah(sp)+" / "+rupiah(lim),13,muted,false));
                ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(100);bar.setProgress((int)Math.min(100,lim==0?0:sp/lim*100));l.addView(bar);
                Button del=button("Hapus");del.setOnClickListener(v->{budgets.remove(cat);save();});l.addView(del);card(l);}
        }else if(tab.equals("Target")){
            Button b=button("＋ Buat target tabungan");b.setOnClickListener(v->goalDialog());card(b);
            for(int i=0;i<goals.length();i++){final int idx=i;JSONObject g=goals.optJSONObject(i);if(g==null)continue;
                LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.addView(text(g.optString("name"),17,ink,true));l.addView(text(rupiah(g.optDouble("saved"))+" / "+rupiah(g.optDouble("target")),14,muted,false));
                ProgressBar p=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);p.setMax(100);p.setProgress((int)Math.min(100,g.optDouble("saved")/Math.max(1,g.optDouble("target"))*100));l.addView(p);
                Button plus=button("＋ Tambah tabungan");plus.setOnClickListener(v->addGoal(idx));l.addView(plus);Button del=button("Hapus target");del.setOnClickListener(v->{goals.remove(idx);save();});l.addView(del);card(l);}
        }else{
            label("Pengaturan & Data");Button ex=button("Export backup JSON");ex.setOnClickListener(v->exportData());card(ex);
            Button imp=button("Import backup JSON");imp.setOnClickListener(v->importData());card(imp);
            Button reset=button("Hapus semua data");reset.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Reset DompetKu?").setMessage("Semua transaksi, anggaran dan target akan dihapus.").setNegativeButton("Batal",null).setPositiveButton("Hapus",(d,w)->{transactions=new JSONArray();budgets=new JSONObject();goals=new JSONArray();save();}).show());card(reset);
            card(text("DompetKu v1.0 • Data disimpan offline di perangkat.",12,muted,false));
        }
    }
    double sumCat(String cat){double s=0;for(int i=0;i<transactions.length();i++){JSONObject o=transactions.optJSONObject(i);if(o!=null&&o.optString("type").equals("Pengeluaran")&&o.optString("cat").equals(cat)&&o.optString("date").startsWith(month()))s+=o.optDouble("amount");}return s;}
    void showTransactions(int max){
        ArrayList<JSONObject> arr=new ArrayList<>();for(int i=transactions.length()-1;i>=0;i--)arr.add(transactions.optJSONObject(i));
        if(arr.size()==0){card(text("Belum ada transaksi. Yuk catat transaksi pertamamu!",14,muted,false));return;}
        int count=0;for(JSONObject o:arr){if(o==null||count>=max)break;String type=o.optString("type"),cat=o.optString("cat"),note=o.optString("note"),date=o.optString("date");
            LinearLayout row=new LinearLayout(this);row.setOrientation(1);row.setPadding(0,dp(8),0,dp(8));
            row.addView(text((note.isEmpty()?cat:note)+"  •  "+date,14,ink,true));
            row.addView(text((type.equals("Pemasukan")?"+ ":"− ")+rupiah(o.optDouble("amount"))+"  |  "+cat,13,type.equals("Pemasukan")?Color.rgb(20,145,100):Color.rgb(210,70,80),true));
            card(row);count++;
        }
    }
    void transactionDialog(){
        LinearLayout l=new LinearLayout(this);l.setOrientation(1);ScrollView sc=new ScrollView(this);sc.addView(l);
        Spinner type=new Spinner(this);String[] types={"Pengeluaran","Pemasukan"};type.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,types));l.addView(type);
        EditText amount=new EditText(this);amount.setHint("Nominal (Rp)");amount.setInputType(2);l.addView(amount);
        Spinner cat=new Spinner(this);l.addView(cat);
        type.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?>p){}public void onItemSelected(android.widget.AdapterView<?>p,View v,int pos,long id){String[] c=pos==0?expenseCats:incomeCats;cat.setAdapter(new ArrayAdapter<>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item,c);}});
        EditText note=new EditText(this);note.setHint("Catatan (opsional)");l.addView(note);
        EditText date=new EditText(this);date.setHint("Tanggal YYYY-MM-DD");date.setText(new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()));l.addView(date);
        new AlertDialog.Builder(this).setTitle("Catat transaksi").setView(sc).setNegativeButton("Batal",null).setPositiveButton("Simpan",(d,w)->{try{double a=Double.parseDouble(amount.getText().toString());if(a<=0)return;JSONObject o=new JSONObject();o.put("type",type.getSelectedItem().toString());o.put("amount",a);o.put("cat",cat.getSelectedItem().toString());o.put("note",note.getText().toString());o.put("date",date.getText().toString());transactions.put(o);save();}catch(Exception e){Toast.makeText(this,"Nominal tidak valid",Toast.LENGTH_SHORT).show();}}).show();
    }
    void budgetDialog(){
        EditText cat=new EditText(this);cat.setHint("Kategori (mis. Makanan)");
        EditText amount=new EditText(this);amount.setHint("Batas anggaran (Rp)");amount.setInputType(2);
        LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.addView(cat);l.addView(amount);
        new AlertDialog.Builder(this).setTitle("Anggaran bulanan").setView(l).setNegativeButton("Batal",null).setPositiveButton("Simpan",(d,w)->{try{budgets.put(cat.getText().toString(),Double.parseDouble(amount.getText().toString()));save();}catch(Exception e){}}).show();
    }
    void goalDialog(){
        EditText name=new EditText(this);name.setHint("Nama target (mis. Laptop)");
        EditText amount=new EditText(this);amount.setHint("Target nominal (Rp)");amount.setInputType(2);
        LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.addView(name);l.addView(amount);
        new AlertDialog.Builder(this).setTitle("Target tabungan").setView(l).setNegativeButton("Batal",null).setPositiveButton("Buat",(d,w)->{try{JSONObject g=new JSONObject();g.put("name",name.getText().toString());g.put("target",Double.parseDouble(amount.getText().toString()));g.put("saved",0);goals.put(g);save();}catch(Exception e){}}).show();
    }
    void addGoal(int idx){EditText a=new EditText(this);a.setHint("Nominal tabungan (Rp)");a.setInputType(2);new AlertDialog.Builder(this).setTitle("Tambah tabungan").setView(a).setNegativeButton("Batal",null).setPositiveButton("Simpan",(d,w)->{try{JSONObject g=goals.getJSONObject(idx);g.put("saved",g.optDouble("saved")+Double.parseDouble(a.getText().toString()));save();}catch(Exception e){}}).show();}
    void exportData(){
        try{JSONObject data=new JSONObject();data.put("tx",transactions);data.put("budgets",budgets);data.put("goals",goals);
            String s=data.toString(2);android.content.Intent i=new android.content.Intent(android.content.Intent.ACTION_SEND);i.setType("application/json");i.putExtra(android.content.Intent.EXTRA_TEXT,s);startActivity(android.content.Intent.createChooser(i,"Simpan/kirim backup DompetKu"));
        }catch(Exception e){Toast.makeText(this,"Export gagal",Toast.LENGTH_SHORT).show();}
    }
    void importData(){
        EditText input=new EditText(this);input.setHint("Tempel isi JSON backup di sini");new AlertDialog.Builder(this).setTitle("Import backup").setView(input).setNegativeButton("Batal",null).setPositiveButton("Import",(d,w)->{try{JSONObject j=new JSONObject(input.getText().toString());transactions=j.getJSONArray("tx");budgets=j.getJSONObject("budgets");goals=j.getJSONArray("goals");save();}catch(Exception e){Toast.makeText(this,"JSON tidak valid",Toast.LENGTH_LONG).show();}}).show();
    }
}